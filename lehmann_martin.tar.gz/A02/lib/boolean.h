#pragma once

#define boolean int
#define true 0
#define false 1

void print_boolean(boolean value);